package com.example.myapplication;

import static org.junit.Assert.*;
import org.junit.Test;

//in this test, I choose the decision "if (Side1 <= 0 || Side2 <= 0 || Side3 <= 0)"
//and write a JunitTest to satisfy MC/DC coverage
public class TritypeMCDCTest {
    @Test
    public void testMCDC() {
        Tritype tri = new Tritype();
        assertEquals(4, tri.Triang(1, 2, -3));
    }

}