package com.example.myapplication;

import static org.junit.Assert.*;
import org.junit.Test;
public class TritypeMutationTest {
    //'testMutationOne' is to kill the mutationOne
    //run this test, we can find it passed
    @Test
    public void testMutationOne() {
        int side1 = 5;
        int side2 = 5;
        int side3 = 8;

        int result = TritypeMutantOne.Triang(side1, side2, side3);

        // 期望的是等腰三角形，因此 triOut 应该等于 2
        assertEquals(2, result);
    }

    //'testMutationTwo' is to kill the mutationTwo
    @Test
    public void testMutationTwo(){
        int side1 = 3;
        int side2 = 3;
        int side3 = 2;
        int result = TritypeMutantOne.Triang(side1, side2, side3);
        // 期望的是等腰三角形，因此 triOut 应该等于 2
        assertEquals(2, result);
    }

}
