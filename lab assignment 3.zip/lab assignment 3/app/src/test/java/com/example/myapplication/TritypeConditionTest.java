package com.example.myapplication;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

//in this test, I choose the decision "else if (triOut == 1 && Side1+Side2 > Side3)"
//and write a JunitTest to satisfy condition coverage
public class TritypeConditionTest {
    @Test
    public void testConditionTrue() {
        // Triang(3, 4, 5) will set triOut to 1 and satisfy the condition
        Tritype tri = new Tritype();
        assertEquals(1, tri.Triang(3, 4, 5));
    }

    @Test
    public void testConditionFalse() {
        // Triang(1, 2, 3) will set triOut to 4 and not satisfy the condition
        Tritype tri = new Tritype();
        assertEquals(4, tri.Triang(1, 2, 3));
    }
}
