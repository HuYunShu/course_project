package com.example.myapplication;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

//in this test, I choose the decision "if (Side1 <= 0 || Side2 <= 0 || Side3 <= 0)"
//and write a JunitTest to satisfy decision coverage
public class TritypeDecisionTest1 {

    @Test
    public void testNegativeSide() {
        Tritype tri = new Tritype();
        assertEquals(4, tri.Triang(-1, 2, 3));
    }

    @Test
    public void testPositiveSides() {
        Tritype tri = new Tritype();
        assertEquals(0, tri.Triang(3, 4, 5));
    }
}
